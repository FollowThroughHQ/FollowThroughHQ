# Legal checklist

This is a to-do list, not legal advice. Have a lawyer review the legal pages before promoting the site, especially because the owner is in Europe and the audience is in the US.

## Pages included
- **Privacy policy:** what is collected, browser storage, third parties, rights, children, changes.
- **Terms of use:** information only, intellectual property, limitation of liability, governing law.
- **Disclaimer:** not professional advice, estimates only, no income promises, no affiliation.

## Fill in
Name or company, address, country, governing law, last-updated date, contact email.

## Update when things change
- When signups go to Google Sheets, add Google as a service provider in the privacy policy.
- When analytics are added, describe them and add a cookie banner if required.
- When you sell anything, add refund terms and a payment provider mention.
- When you add testimonials, get written permission.

## Email compliance
- **US (CAN-SPAM):** real sender identity, physical address, unsubscribe link honored promptly, accurate subject lines.
- **EU/UK (GDPR):** consent for marketing, easy withdrawal, keep data minimal, delete on request, record consent time and wording.
- Do not cold text US numbers.

## Business setup
Check your own country's rules for registering as a sole trader or company, VAT on digital sales, and invoicing.
